﻿using ANeuralNetwork;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compression_Year_Project
{
    class Compress
    {
        private BackPropNetwork bpnetwork;
        private NetworkTrainer nt;
        private DataSet ds;
        private string compressedString;
        public Compress()
        {
            int[] layersizes = new int[10] { 1,10,9,8,7,5,4,3,2,1 };
            ActivationFunction[] activFunctions = new ActivationFunction[10]{ ActivationFunction.None,ActivationFunction.Gaussian,ActivationFunction.Gaussian,ActivationFunction.Gaussian,ActivationFunction.Gaussian,ActivationFunction.Sigmoid,ActivationFunction.Sigmoid,ActivationFunction.Sigmoid,ActivationFunction.Sigmoid,
                ActivationFunction.Linear };
          

            XmlDocument xdoc = new XmlDocument();
            xdoc.Load("ann.xml");

            ds = new DataSet();
            ds.Load((XmlElement)xdoc.DocumentElement.ChildNodes[0]);


            bpnetwork = new BackPropNetwork(layersizes, activFunctions);
            nt = new NetworkTrainer(bpnetwork, ds);

            nt.maxError = 0.1;
            nt.maxiterations = 10000;
            nt.traininrate = 0.3;
            nt.TrainDataset();

            // save error
            double[] err = nt.geteHistory();
            string[] filedata = new string[err.Length];

            for (int i = 0; i < err.Length; i++)
            {
                filedata[i] = i.ToString() + " " + err[i].ToString();
            }

            File.WriteAllLines("../xornetwrk.txt", filedata);
        }
        public void compressFile(Normalise norm)
        {
            List<int> indices = new List<int>();
            for (int i = 0; i < norm._inputData.Length; i++)
            {
                double[] tmpInput = new double[1];
                double[] tmpOutput = new double[1];

                tmpInput[0] = norm._inputData[i];
                bpnetwork.run(ref tmpInput, out tmpOutput);

                double checkVal = Math.Round(tmpOutput[0], 3);
                int check = 0;
                foreach (KeyValuePair<string, double> kv in norm._map)
                {
                    if ((kv.Value - checkVal >= -0.03) && (kv.Value - checkVal <= 0.03))
                    {
                        indices.Add(check);
                        check++;
                    }
                    else
                    {
                        check++;
                    }
                }
            }
            foreach (int i in indices)
            {
                double val = norm._map[i].Value;
                norm._map[i] = new KeyValuePair<string, double>("X", val);
            }
            foreach (KeyValuePair<string, double> kv in norm._map)
            {
                for (int j = 0; j < norm._worddata.Length; j++)
                {
                    if (norm._inputData[j] == kv.Value)
                    {
                        norm._worddata[j] = kv.Key;
                    }
                }
            }
            for (int k = 0; k < norm._worddata.Length; k++)
            {
                compressedString += norm._worddata[k];
            }
        }
        public string _compressedString
        {
            get
            {
                return this.compressedString;
            }
        }
        public BackPropNetwork _bpnetwwork
        {
            get
            {
                return bpnetwork;
            }
        }

    }
}
